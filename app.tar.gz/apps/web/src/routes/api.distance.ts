import { apiError, json, withApi } from '@/lib/api.server';
import { findAirportByCode, haversineMiles } from '@/lib/airports';

type DistanceElement = {
  status?: string;
  distance?: { value?: number; text?: string };
  duration?: { value?: number; text?: string };
};

type DistanceResponse = {
  status?: string;
  rows?: { elements?: DistanceElement[] }[];
};

/**
 * GET /api/distance?origin=...&destination=...
 *
 * Driving distance + duration via Google Distance Matrix when
 * GOOGLE_MAPS_API_KEY is set. Without a key — or when Google denies the
 * request (e.g. an API key with billing disabled or restricted APIs) — falls
 * back to a straight-line (haversine) estimate when both endpoints resolve to
 * known airport codes. When no distance can be computed at all, returns
 * `available: false` with `fallback: "minimum"` so the booking flow quotes the
 * operator's minimum fare as a "from" price instead of hiding the fare
 * entirely. The customer always sees a fare; the final fare is confirmed
 * before pickup based on actual distance.
 */
export const loader = withApi(async ({ request }) => {
  const url = new URL(request.url);
  const origin = (url.searchParams.get('origin') ?? '').trim();
  const destination = (url.searchParams.get('destination') ?? '').trim();
  const configured = Boolean(process.env.GOOGLE_MAPS_API_KEY);

  if (!origin || !destination) {
    return apiError(422, 'origin and destination query params are required');
  }

  if (configured) {
    const key = process.env.GOOGLE_MAPS_API_KEY as string;
    try {
      const upstream = await fetch(
        `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${encodeURIComponent(origin)}&destinations=${encodeURIComponent(destination)}&units=imperial&key=${key}`,
        { signal: request.signal },
      );

      if (upstream.ok) {
        const data = (await upstream.json()) as DistanceResponse;
        const element = data.rows?.[0]?.elements?.[0];

        if (element?.status === 'OK' && element.distance?.value && element.duration?.value) {
          return json({
            available: true,
            configured: true,
            source: 'google',
            miles: element.distance.value / 1609.344,
            durationSeconds: element.duration.value,
            distanceText: element.distance.text,
            durationText: element.duration.text,
          });
        }
      }
    } catch {
      // Network blip or abort — fall through to the airport straight-line
      // fallback below so a transient failure never hides the fare.
    }
    // Google denied the key or found no route — fall through to the airport
    // straight-line fallback rather than returning "unavailable" immediately.
  }

  // Airport straight-line fallback. Used both when no key is configured and
  // when Google denies the request, so airport-to-airport fares always work.
  const originAirport = findAirportByCode(origin) ?? findAirportByCode(origin.split(' ')[0]);
  const destAirport = findAirportByCode(destination) ?? findAirportByCode(destination.split(' ')[0]);

  if (originAirport && destAirport) {
    const miles = haversineMiles(originAirport.lat, originAirport.lng, destAirport.lat, destAirport.lng);
    return json({
      available: true,
      configured,
      source: 'airports',
      miles,
      durationSeconds: Math.round((miles / 45) * 3600),
      distanceText: `${miles.toFixed(0)} mi (straight-line)`,
      durationText: `~${Math.round((miles / 45) * 60)} min`,
      note: 'Straight-line estimate between airports. Add a Google Maps API key for driving distance.',
    });
  }

  // No distance can be computed. Signal the booking flow to quote the
  // operator's minimum fare as a "from" price so the customer always sees a
  // fare, with a note that the final fare is confirmed before pickup.
  return json({
    available: false,
    configured,
    source: configured ? 'google' : 'airports',
    fallback: 'minimum',
    message: configured
      ? 'Live distance is unavailable right now. Your estimated fare starts at the minimum fare; the final fare is confirmed before pickup.'
      : 'Google Maps API key not configured. Live distance is unavailable for non-airport addresses.',
  });
});
